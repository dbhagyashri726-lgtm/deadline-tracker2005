let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

function addTask() {

    const taskName = document.getElementById("taskInput").value;
    const date = document.getElementById("dateInput").value;
    const time = document.getElementById("timeInput").value;

    if (taskName === "" || date === "" || time === "") {
        alert("Please enter task, date and time.");
        return;
    }

    const task = {
        id: Date.now(),
        name: taskName,
        date: date,
        time: time,
        completed: false
    };

    tasks.push(task);

    saveTasks();

    document.getElementById("taskInput").value = "";
    document.getElementById("dateInput").value = "";
    document.getElementById("timeInput").value = "";

    displayTasks(tasks);
}

function displayTasks(taskArray) {

    const taskList = document.getElementById("taskList");

    taskList.innerHTML = "";

    taskArray.forEach(task => {

        const deadline = new Date(`${task.date}T${task.time}`);
        const now = new Date();

        let overdue = deadline < now && !task.completed;

        const div = document.createElement("div");

        div.className = "task";

        if (task.completed) {
            div.classList.add("completed");
        }

        if (overdue) {
            div.classList.add("overdue");
        }

        div.innerHTML = `
            <h3>${task.name}</h3>

            <p>
                📅 ${task.date}
                &nbsp;
                ⏰ ${task.time}
            </p>

            <p>
                Status:
                ${task.completed ? "✅ Completed" : overdue ? "🔴 Overdue" : "🟢 Pending"}
            </p>

            <div class="task-buttons">

                ${
                    !task.completed
                    ? `<button class="complete-btn"
                        onclick="completeTask(${task.id})">
                        Complete
                       </button>`
                    : ""
                }

                <button class="delete-btn"
                    onclick="deleteTask(${task.id})">
                    Delete
                </button>

            </div>
        `;

        taskList.appendChild(div);
    });
}

function completeTask(id) {

    tasks = tasks.map(task => {

        if (task.id === id) {
            task.completed = true;
        }

        return task;
    });

    saveTasks();
    displayTasks(tasks);
}

function deleteTask(id) {

    tasks = tasks.filter(task => task.id !== id);

    saveTasks();
    displayTasks(tasks);
}

function showAll() {
    displayTasks(tasks);
}

function showPending() {

    const pending = tasks.filter(task => !task.completed);

    displayTasks(pending);
}

function showCompleted() {

    const completed = tasks.filter(task => task.completed);

    displayTasks(completed);
}

function saveTasks() {

    localStorage.setItem("tasks", JSON.stringify(tasks));

}

displayTasks(tasks);